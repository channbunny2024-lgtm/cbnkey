const express = require('express');
const router = express.Router();
const rateLimit = require('express-rate-limit');
const CryptoService = require('../services/cryptoService');
const LicenseService = require('../services/licenseService');

// Admin Rate Limiter to prevent brute-force attacks on admin controller
const adminLimiter = rateLimit({
    windowMs: 1 * 60 * 1000,
    max: 120, // 120 requests per minute
    standardHeaders: true,
    legacyHeaders: false,
    validate: { xForwardedForHeader: false },
    message: {
        success: false,
        message: 'Too many administrative requests. Please slow down.'
    }
});

// Admin Key Authentication Middleware (Constant-Time Safe)
function checkAdminAuth(req, res, next) {
    const adminKey = process.env.ADMIN_API_KEY || 'CBN-ADMIN-SECRET-KEY-9988';
    const providedKey = req.headers['x-admin-key'] || req.query.admin_key || req.body?.admin_key;
    
    // 1. Direct valid Admin Key provided with constant-time comparison
    if (providedKey && typeof providedKey === 'string' && CryptoService.safeCompare(providedKey, adminKey)) {
        return next();
    }

    // 2. Allow same-origin web dashboard and local loopback requests
    const origin = req.headers.origin || req.headers.referer || '';
    const host = req.headers.host || '';
    const isSameHost = host && (origin.includes(host) || origin.includes('localhost') || origin.includes('127.0.0.1'));
    const isLocalIp = req.ip === '127.0.0.1' || req.ip === '::1' || req.ip === '::ffff:127.0.0.1';

    if (isSameHost || isLocalIp) {
        return next();
    }

    // 3. Unauthorized
    return res.status(401).json({
        success: false,
        message: 'Unauthorized: Invalid or missing X-Admin-Key header'
    });
}

router.use(adminLimiter);
router.use(checkAdminAuth);

/**
 * @route   POST /api/admin/licenses/generate
 * @desc    Generate a new encrypted license key
 */
router.post('/licenses/generate', async (req, res) => {
    try {
        const {
            customer_name,
            customer_email,
            tier,
            days_valid,
            max_activations,
            notes,
            prefix,
            custom_features
        } = req.body;

        const license = await LicenseService.createLicense({
            customer_name: customer_name || 'Enterprise Customer',
            customer_email,
            tier: tier || 'Enterprise',
            days_valid: days_valid || 365,
            max_activations: max_activations !== undefined ? max_activations : 1,
            notes,
            prefix: prefix || 'CBN',
            custom_features
        });

        res.status(201).json({
            success: true,
            message: 'License key successfully generated and encrypted',
            license
        });
    } catch (error) {
        console.error('[Admin] generate error:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

/**
 * @route   POST /api/admin/licenses/batch-generate
 * @desc    Generate multiple encrypted license keys at once
 */
router.post('/licenses/batch-generate', async (req, res) => {
    try {
        const { count = 5, customer_name, tier, days_valid, max_activations, prefix } = req.body;
        const total = Math.min(Math.max(parseInt(count, 10) || 1, 1), 50); // Max 50 per batch
        const generated = [];

        for (let i = 0; i < total; i++) {
            const lic = await LicenseService.createLicense({
                customer_name: `${customer_name || 'Batch Customer'} #${i + 1}`,
                tier: tier || 'Enterprise',
                days_valid: days_valid || 365,
                max_activations: max_activations || 1,
                prefix: prefix || 'CBN'
            });
            generated.push(lic);
        }

        res.status(201).json({
            success: true,
            count: generated.length,
            licenses: generated
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

/**
 * @route   GET /api/admin/licenses
 * @desc    Get all licenses with search and filtering
 */
router.get('/licenses', async (req, res) => {
    try {
        const { search, status, tier, limit, offset } = req.query;
        const data = await LicenseService.getAllLicenses({ search, status, tier, limit, offset });
        res.json({
            success: true,
            ...data
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

/**
 * @route   GET /api/admin/licenses/:id
 * @desc    Get license details, active machines, and audit logs
 */
router.get('/licenses/:id', async (req, res) => {
    try {
        const license = await LicenseService.getLicenseById(req.params.id);
        if (!license) {
            return res.status(404).json({ success: false, message: 'License not found' });
        }
        res.json({ success: true, license });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

/**
 * @route   PUT /api/admin/licenses/:id/revoke
 * @desc    Revoke a license immediately
 */
router.put('/licenses/:id/revoke', async (req, res) => {
    try {
        const { reason } = req.body;
        const result = await LicenseService.revokeLicense(req.params.id, reason);
        res.json(result);
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

/**
 * @route   PUT /api/admin/licenses/:id/extend
 * @desc    Extend license expiration by N days
 */
router.put('/licenses/:id/extend', async (req, res) => {
    try {
        const { additional_days = 30 } = req.body;
        const result = await LicenseService.extendLicense(req.params.id, additional_days);
        res.json(result);
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

/**
 * @route   DELETE /api/admin/licenses/:id
 * @desc    Delete a license
 */
router.delete('/licenses/:id', async (req, res) => {
    try {
        const result = await LicenseService.deleteLicense(req.params.id);
        res.json(result);
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

/**
 * @route   GET /api/admin/telemetry
 * @desc    System telemetry summary counters & recent activity
 */
router.get('/telemetry', async (req, res) => {
    try {
        const telemetry = await LicenseService.getTelemetrySummary();
        res.json({ success: true, telemetry });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

/**
 * @route   DELETE /api/admin/telemetry/logs
 * @desc    Clear all verification audit logs
 */
router.delete('/telemetry/logs', async (req, res) => {
    try {
        const result = await LicenseService.clearVerificationLogs();
        res.json(result);
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

module.exports = router;
