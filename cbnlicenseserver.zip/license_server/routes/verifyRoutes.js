const express = require('express');
const router = express.Router();
const rateLimit = require('express-rate-limit');
const LicenseService = require('../services/licenseService');

// Verification Rate Limiter: Max 60 requests per minute per IP
const verifyLimiter = rateLimit({
    windowMs: 1 * 60 * 1000,
    max: 60,
    standardHeaders: true,
    legacyHeaders: false,
    validate: { xForwardedForHeader: false },
    message: {
        valid: false,
        message: 'Too many verification attempts from this client IP. Please try again later.'
    }
});

/**
 * @route   POST /api/verify-license, /api/license/activate, /api/activate-license, etc.
 * @desc    Client License Verification & Hardware Binding Activation Endpoint
 * @access  Public (Rate-limited)
 */
router.post([
    '/verify-license',
    '/license/verify',
    '/license/activate',
    '/activate-license',
    '/activate',
    '/verify'
], verifyLimiter, async (req, res) => {
    try {
        // Support all common property casing & naming variations (key, license_key, licenseKey, machine_id, hwid, etc.)
        const key = req.body?.key || req.body?.license_key || req.body?.licenseKey || req.body?.LicenseKey || req.body?.Key || req.query?.key || req.query?.license_key;
        const machine_name = req.body?.machine_name || req.body?.machineName || req.body?.machine_id || req.body?.machineId || req.body?.hwid || req.body?.deviceId || req.body?.device_id || req.body?.MachineName || req.headers['user-agent'] || 'UNKNOWN-WORKSTATION';
        const client_version = req.body?.client_version || req.body?.clientVersion || req.body?.version || req.body?.ClientVersion || '1.0';
        const ip_address = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1';

        if (!key) {
            return res.status(200).json({
                valid: false,
                success: false,
                message: 'License key cannot be empty (expected parameter: "key" or "license_key")'
            });
        }

        const result = await LicenseService.verifyLicense({
            key,
            machine_name,
            client_version,
            ip_address
        });

        // Attach success flag alongside valid flag for compatibility with various client libraries
        result.success = result.valid;

        return res.status(200).json(result);
    } catch (error) {
        console.error('[VerifyRoute] Internal error:', error);
        return res.status(500).json({
            valid: false,
            success: false,
            message: `Internal server verification error: ${error.message}`
        });
    }
});

/**
 * @route   GET /api/verify-license
 * @desc    Informational Guide or Quick GET verification (for browser / diagnostics)
 * @access  Public
 */
router.get(['/verify-license', '/license/verify'], verifyLimiter, async (req, res) => {
    try {
        const { key, client_version, machine_name } = req.query;

        // If a key query parameter is provided, execute verification
        if (key) {
            const ip_address = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1';
            const result = await LicenseService.verifyLicense({
                key,
                machine_name: machine_name || req.headers['user-agent'] || 'BROWSER-GET-TEST',
                client_version: client_version || '1.0',
                ip_address
            });
            return res.status(200).json(result);
        }

        // Otherwise, return clear endpoint documentation & status
        return res.status(200).json({
            service: 'CBN TECH Cryptographic License Verification API',
            status: 'ONLINE',
            endpoint: '/api/verify-license',
            methods_supported: ['POST', 'GET'],
            description: 'Cryptographic HMAC-SHA256 & AES-256 License Key Verification Engine',
            usage: {
                recommended_method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body_schema: {
                    key: 'CBN-XXXX-XXXX-XXXX-XXXX (Required: License key string)',
                    machine_name: 'WORKSTATION-01 (Optional: Device / Kiosk hostname)',
                    client_version: '2.4.0 (Optional: Client build version)'
                },
                get_test_example: '/api/verify-license?key=CBN-XXXX-XXXX-XXXX-XXXX'
            },
            admin_dashboard: '/',
            health_check: '/api/health',
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('[VerifyRoute] GET error:', error);
        return res.status(500).json({
            valid: false,
            message: `Internal server verification error: ${error.message}`
        });
    }
});

/**
 * @route   GET /api/health
 * @desc    Health Check Endpoint
 */
router.get('/health', (req, res) => {
    res.json({
        status: 'ONLINE',
        service: 'CBN TECH Cryptographic License Server',
        timestamp: new Date().toISOString()
    });
});

module.exports = router;
