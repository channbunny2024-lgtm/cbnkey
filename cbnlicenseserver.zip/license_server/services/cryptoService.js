const crypto = require('crypto');
require('dotenv').config();

// Resolve 32-byte encryption key
const RAW_SECRET = process.env.ENCRYPTION_SECRET || 'dpms_enterprise_license_encryption_master_key_2026_secure!';
const ENCRYPTION_KEY = crypto.createHash('sha256').update(RAW_SECRET).digest(); // Exactly 32 bytes

// Resolve HMAC signature key
const HMAC_KEY = process.env.HMAC_SIGNATURE_KEY || 'dpms_enterprise_hmac_master_signature_key_2026';
const LICENSE_PREFIX = process.env.LICENSE_PREFIX || 'CBN';

class CryptoService {
    /**
     * Generates a secure, human-readable, cryptographically signed license key.
     * Format: PREFIX-XXXX-XXXX-XXXX-XXXX (e.g., CBN-8F92-4C7E-902B-1E5A)
     */
    static generateLicenseKey(customPrefix = LICENSE_PREFIX) {
        const prefix = (customPrefix || LICENSE_PREFIX).toUpperCase();
        
        // Generate 6 bytes (12 hex characters) of cryptographic entropy for blocks 1, 2, 3
        const randomBytes = crypto.randomBytes(6);
        const hex = randomBytes.toString('hex').toUpperCase();
        
        // Compute 4-byte (4 hex char) HMAC verification signature of the 6-byte random payload
        const signature = crypto.createHmac('sha256', HMAC_KEY)
                                .update(randomBytes)
                                .digest('hex')
                                .substring(0, 4)
                                .toUpperCase();
        
        // Segment into 4 blocks of 4 alphanumeric chars
        const block1 = hex.substring(0, 4);
        const block2 = hex.substring(4, 8);
        const block3 = hex.substring(8, 12);
        const block4 = signature; // Last segment is cryptographic checksum

        return `${prefix}-${block1}-${block2}-${block3}-${block4}`;
    }

    /**
     * Computes SHA-256 hash of a license key for constant-time, indexed database lookups.
     */
    static hashKey(licenseKey) {
        if (!licenseKey) return '';
        const normalized = licenseKey.trim().toUpperCase();
        return crypto.createHash('sha256').update(normalized).digest('hex');
    }

    /**
     * Encrypts a JSON payload or string using AES-256-GCM (Authenticated Encryption).
     * Returns a base64 or hex encoded string formatted as: iv:authTag:ciphertext
     */
    static encryptPayload(data) {
        try {
            const plainText = typeof data === 'object' ? JSON.stringify(data) : String(data);
            const iv = crypto.randomBytes(12); // Standard 96-bit IV for GCM
            const cipher = crypto.createCipheriv('aes-256-gcm', ENCRYPTION_KEY, iv);
            
            let encrypted = cipher.update(plainText, 'utf8', 'hex');
            encrypted += cipher.final('hex');
            
            const authTag = cipher.getAuthTag().toString('hex');
            
            return `${iv.toString('hex')}:${authTag}:${encrypted}`;
        } catch (error) {
            console.error('[CryptoService] Encryption error:', error.message);
            throw new Error('Failed to encrypt license payload');
        }
    }

    /**
     * Decrypts an AES-256-GCM encrypted payload.
     */
    static decryptPayload(encryptedData) {
        try {
            if (!encryptedData || typeof encryptedData !== 'string') return null;
            
            const parts = encryptedData.split(':');
            if (parts.length !== 3) {
                throw new Error('Invalid encrypted payload format');
            }

            const [ivHex, authTagHex, cipherTextHex] = parts;
            const iv = Buffer.from(ivHex, 'hex');
            const authTag = Buffer.from(authTagHex, 'hex');
            
            const decipher = crypto.createDecipheriv('aes-256-gcm', ENCRYPTION_KEY, iv);
            decipher.setAuthTag(authTag);
            
            let decrypted = decipher.update(cipherTextHex, 'hex', 'utf8');
            decrypted += decipher.final('utf8');

            try {
                return JSON.parse(decrypted);
            } catch {
                return decrypted;
            }
        } catch (error) {
            console.error('[CryptoService] Decryption error:', error.message);
            return null;
        }
    }

    /**
     * Constant-time timing-safe string comparison to protect against timing attacks.
     */
    static safeCompare(a, b) {
        if (typeof a !== 'string' || typeof b !== 'string') return false;
        const aHash = crypto.createHash('sha256').update(a).digest();
        const bHash = crypto.createHash('sha256').update(b).digest();
        return crypto.timingSafeEqual(aHash, bHash);
    }

    /**
     * Sanitizes user input string, stripping control chars, HTML tags, and null bytes.
     */
    static sanitizeString(input, maxLength = 255) {
        if (!input || typeof input !== 'string') return '';
        return input
            .replace(/\0/g, '') // remove null bytes
            .replace(/<[^>]*>?/gm, '') // strip html tags
            .replace(/[\x00-\x1F\x7F]/g, '') // strip control chars
            .trim()
            .substring(0, maxLength);
    }

    /**
     * Verifies structural integrity & HMAC checksum of a license key.
     */
    static verifyKeyFormat(licenseKey) {
        if (!licenseKey || typeof licenseKey !== 'string') return false;
        const trimmed = licenseKey.trim().toUpperCase();
        
        // Strict format regex: PREFIX-4HEX-4HEX-4HEX-4HEX
        const regex = /^[A-Z0-9]{2,8}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}$/;
        if (!regex.test(trimmed)) return false;

        const parts = trimmed.split('-');
        const randomHex = parts[1] + parts[2] + parts[3];
        const signature = parts[4];

        try {
            const expectedSig = crypto.createHmac('sha256', HMAC_KEY)
                                      .update(Buffer.from(randomHex, 'hex'))
                                      .digest('hex')
                                      .substring(0, 4)
                                      .toUpperCase();

            return this.safeCompare(signature, expectedSig);
        } catch {
            return false;
        }
    }
}

module.exports = CryptoService;
