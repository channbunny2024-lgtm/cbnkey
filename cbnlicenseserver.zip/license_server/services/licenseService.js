const { getPool, getIsConnected } = require('../config/db');
const CryptoService = require('./cryptoService');

// Fallback in-memory store for instant zero-dependency execution if MySQL is temporarily offline
const memoryStore = {
    licenses: [],
    activations: [],
    logs: []
};

class LicenseService {
    /**
     * Verifies a client license key, checks expiry and machine activation quota, logs telemetry.
     */
    static async verifyLicense({ key, machine_name = 'UNKNOWN-MACHINE', client_version = '1.0', ip_address = '127.0.0.1' }) {
        const cleanMachine = CryptoService.sanitizeString(machine_name, 100) || 'UNKNOWN-WORKSTATION';
        const cleanVersion = CryptoService.sanitizeString(client_version, 30) || '1.0';
        const cleanIp = CryptoService.sanitizeString(ip_address, 45) || '127.0.0.1';

        if (!key || typeof key !== 'string') {
            await this.logVerification(null, false, 'EMPTY_KEY', cleanMachine, cleanIp, cleanVersion, 'License key was empty');
            return { valid: false, message: 'License key cannot be empty' };
        }

        const normalizedKey = CryptoService.sanitizeString(key, 64).toUpperCase();
        const keyHash = CryptoService.hashKey(normalizedKey);
        const now = new Date();

        try {
            const pool = getPool();
            let license = null;

            if (pool && getIsConnected()) {
                const [rows] = await pool.query('SELECT * FROM `licenses` WHERE `key_hash` = ? LIMIT 1', [keyHash]);
                if (rows.length > 0) {
                    license = rows[0];
                }
            } else {
                // In-memory fallback
                license = memoryStore.licenses.find(l => l.key_hash === keyHash);
            }

            if (!license) {
                await this.logVerification(normalizedKey, false, 'NOT_FOUND', cleanMachine, cleanIp, cleanVersion, 'License key does not exist');
                return { valid: false, message: 'Invalid or unrecognized license key' };
            }

            // Check Status
            if (license.status === 'revoked') {
                await this.logVerification(normalizedKey, false, 'REVOKED', machine_name, ip_address, client_version, 'License is revoked');
                return { valid: false, message: 'License has been revoked by system administrator' };
            }

            if (license.status === 'suspended') {
                await this.logVerification(normalizedKey, false, 'SUSPENDED', machine_name, ip_address, client_version, 'License is suspended');
                return { valid: false, message: 'License is currently suspended. Please contact enterprise support.' };
            }

            // Check Expiry Date
            const expiryDate = new Date(license.expires_at);
            if (now > expiryDate) {
                // Automatically update status to expired if not already
                if (license.status !== 'expired') {
                    await this.updateStatus(license.id, 'expired');
                }
                await this.logVerification(normalizedKey, false, 'EXPIRED', machine_name, ip_address, client_version, 'License has expired');
                return { 
                    valid: false, 
                    message: `License expired on ${expiryDate.toISOString().split('T')[0]}`,
                    expiry: expiryDate.toISOString()
                };
            }

            // Check & Register Machine Activation
            const activationResult = await this.handleMachineActivation(license, machine_name, client_version, ip_address);
            if (!activationResult.success) {
                await this.logVerification(normalizedKey, false, 'DEVICE_LIMIT_EXCEEDED', machine_name, ip_address, client_version, activationResult.message);
                return { valid: false, message: activationResult.message };
            }

            // Successful Verification
            await this.logVerification(normalizedKey, true, 'ACTIVE_VERIFIED', machine_name, ip_address, client_version, 'License verified successfully');
            
            // Decrypt payload to get additional custom metadata
            const metadata = CryptoService.decryptPayload(license.encrypted_payload) || {};

            return {
                valid: true,
                message: 'License verified successfully',
                expiry: expiryDate.toISOString(),
                tier: license.tier || 'Enterprise',
                customer: license.customer_name,
                activations: `${license.current_activations}/${license.max_activations}`,
                features: metadata.features || ['kiosk_hardening', 'tls_encryption', 'terminal_desk', 'operator_multi_user']
            };
        } catch (error) {
            console.error('[LicenseService] verifyLicense error:', error);
            return { valid: false, message: `Verification server internal error: ${error.message}` };
        }
    }

    /**
     * Handles device activation binding, enforce max_activations limit.
     */
    static async handleMachineActivation(license, machine_name, client_version, ip_address) {
        const pool = getPool();
        const now = new Date();

        if (pool && getIsConnected()) {
            // Check if this machine is already activated for this license
            const [existing] = await pool.query(
                'SELECT * FROM `license_activations` WHERE `license_id` = ? AND `machine_name` = ? LIMIT 1',
                [license.id, machine_name]
            );

            if (existing.length > 0) {
                // Machine already registered - update heartbeat
                await pool.query(
                    'UPDATE `license_activations` SET `last_heartbeat` = NOW(), `ip_address` = ?, `client_version` = ? WHERE `id` = ?',
                    [ip_address, client_version, existing[0].id]
                );
                return { success: true };
            }

            // Check activation limits (0 or -1 means unlimited)
            if (license.max_activations > 0 && license.current_activations >= license.max_activations) {
                return {
                    success: false,
                    message: `Maximum device activation limit (${license.max_activations}) reached for this license.`
                };
            }

            // Register new device
            await pool.query(
                'INSERT INTO `license_activations` (`license_id`, `machine_name`, `client_version`, `ip_address`) VALUES (?, ?, ?, ?)',
                [license.id, machine_name, client_version, ip_address]
            );

            // Increment current_activations
            await pool.query(
                'UPDATE `licenses` SET `current_activations` = `current_activations` + 1 WHERE `id` = ?',
                [license.id]
            );
            license.current_activations += 1;

            return { success: true };
        } else {
            // In-Memory Fallback
            const existing = memoryStore.activations.find(a => a.license_id === license.id && a.machine_name === machine_name);
            if (existing) {
                existing.last_heartbeat = now;
                existing.ip_address = ip_address;
                return { success: true };
            }

            if (license.max_activations > 0 && license.current_activations >= license.max_activations) {
                return {
                    success: false,
                    message: `Maximum device activation limit (${license.max_activations}) reached for this license.`
                };
            }

            memoryStore.activations.push({
                id: memoryStore.activations.length + 1,
                license_id: license.id,
                machine_name,
                client_version,
                ip_address,
                first_activated_at: now,
                last_heartbeat: now
            });
            license.current_activations += 1;
            return { success: true };
        }
    }

    /**
     * Generates and stores a new encrypted license key.
     */
    static async createLicense({
        customer_name = 'Valued Customer',
        customer_email = '',
        tier = 'Enterprise',
        days_valid = 365,
        max_activations = 1,
        notes = '',
        prefix = 'CBN',
        custom_features = []
    }) {
        const pool = getPool();
        const cleanName = CryptoService.sanitizeString(customer_name, 120) || 'Enterprise Customer';
        const cleanEmail = CryptoService.sanitizeString(customer_email, 120) || null;
        const cleanNotes = CryptoService.sanitizeString(notes, 255) || null;
        const cleanPrefix = CryptoService.sanitizeString(prefix, 8).toUpperCase() || 'CBN';
        const cleanTier = ['Enterprise', 'Standard', 'Trial', 'Developer'].includes(tier) ? tier : 'Enterprise';
        const cleanDays = Math.max(1, Math.min(parseInt(days_valid, 10) || 365, 36500));
        const cleanMaxAct = Math.max(0, Math.min(parseInt(max_activations, 10) || 1, 10000));

        const licenseKey = CryptoService.generateLicenseKey(cleanPrefix);
        const keyHash = CryptoService.hashKey(licenseKey);

        const now = new Date();
        const expiresAt = new Date(now.getTime() + (cleanDays * 24 * 60 * 60 * 1000));

        // Sanitize features array
        const cleanFeatures = Array.isArray(custom_features) 
            ? custom_features.map(f => CryptoService.sanitizeString(f, 40)).filter(Boolean)
            : ['kiosk_hardening', 'tls_encryption', 'terminal_desk'];

        // Create encrypted metadata payload
        const payloadData = {
            licenseKey,
            customer_name: cleanName,
            customer_email: cleanEmail,
            tier: cleanTier,
            max_activations: cleanMaxAct,
            created_at: now.toISOString(),
            expires_at: expiresAt.toISOString(),
            features: cleanFeatures.length > 0 ? cleanFeatures : ['kiosk_hardening', 'tls_encryption', 'terminal_desk']
        };
        const encryptedPayload = CryptoService.encryptPayload(payloadData);

        const newLicenseRecord = {
            license_key: licenseKey,
            key_hash: keyHash,
            encrypted_payload: encryptedPayload,
            customer_name: cleanName,
            customer_email: cleanEmail,
            tier: cleanTier,
            max_activations: cleanMaxAct,
            current_activations: 0,
            status: 'active',
            expires_at: expiresAt,
            notes: cleanNotes
        };

        if (pool && getIsConnected()) {
            const [result] = await pool.query(
                `INSERT INTO \`licenses\` 
                (\`license_key\`, \`key_hash\`, \`encrypted_payload\`, \`customer_name\`, \`customer_email\`, \`tier\`, \`max_activations\`, \`current_activations\`, \`status\`, \`expires_at\`, \`notes\`) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    newLicenseRecord.license_key,
                    newLicenseRecord.key_hash,
                    newLicenseRecord.encrypted_payload,
                    newLicenseRecord.customer_name,
                    newLicenseRecord.customer_email,
                    newLicenseRecord.tier,
                    newLicenseRecord.max_activations,
                    newLicenseRecord.current_activations,
                    newLicenseRecord.status,
                    newLicenseRecord.expires_at,
                    newLicenseRecord.notes
                ]
            );
            newLicenseRecord.id = result.insertId;
        } else {
            newLicenseRecord.id = memoryStore.licenses.length + 1;
            newLicenseRecord.created_at = now;
            newLicenseRecord.updated_at = now;
            memoryStore.licenses.push(newLicenseRecord);
        }

        return {
            id: newLicenseRecord.id,
            license_key: licenseKey,
            customer_name,
            customer_email,
            tier,
            days_valid: parseInt(days_valid, 10),
            expires_at: expiresAt.toISOString(),
            max_activations: parseInt(max_activations, 10),
            status: 'active'
        };
    }

    /**
     * Retrieves a list of all licenses with optional filtering.
     */
    static async getAllLicenses({ search = '', status = '', tier = '', limit = 100, offset = 0 } = {}) {
        const pool = getPool();

        if (pool && getIsConnected()) {
            let query = `
                SELECT 
                    l.\`id\`, 
                    l.\`license_key\`, 
                    l.\`customer_name\`, 
                    l.\`customer_email\`, 
                    l.\`tier\`, 
                    l.\`max_activations\`, 
                    l.\`current_activations\`, 
                    l.\`status\`, 
                    l.\`expires_at\`, 
                    l.\`created_at\`, 
                    l.\`updated_at\`, 
                    l.\`notes\`,
                    GROUP_CONCAT(DISTINCT la.\`machine_name\` ORDER BY la.\`last_heartbeat\` DESC SEPARATOR '|||') AS \`device_names\`,
                    GROUP_CONCAT(DISTINCT CONCAT(IFNULL(la.\`machine_name\`,''), ':::', IFNULL(la.\`ip_address\`,''), ':::', IFNULL(la.\`client_version\`,''), ':::', IFNULL(la.\`last_heartbeat\`,'')) SEPARATOR '|||') AS \`device_details\`
                FROM \`licenses\` l
                LEFT JOIN \`license_activations\` la ON l.\`id\` = la.\`license_id\`
                WHERE 1=1
            `;
            const params = [];

            if (search) {
                query += ' AND (l.`license_key` LIKE ? OR l.`customer_name` LIKE ? OR l.`customer_email` LIKE ? OR la.`machine_name` LIKE ?)';
                params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
            }
            if (status) {
                query += ' AND l.`status` = ?';
                params.push(status);
            }
            if (tier) {
                query += ' AND l.`tier` = ?';
                params.push(tier);
            }

            query += ' GROUP BY l.`id` ORDER BY l.`created_at` DESC LIMIT ? OFFSET ?';
            params.push(parseInt(limit, 10), parseInt(offset, 10));

            const [rows] = await pool.query(query, params);
            const [[{ total }]] = await pool.query('SELECT COUNT(*) AS total FROM `licenses`');

            // Format devices array for frontend
            const formattedLicenses = rows.map(lic => {
                const deviceNames = lic.device_names ? lic.device_names.split('|||').filter(Boolean) : [];
                const deviceDetails = lic.device_details ? lic.device_details.split('|||').filter(Boolean).map(str => {
                    const [machine_name, ip_address, client_version, last_heartbeat] = str.split(':::');
                    return { machine_name, ip_address, client_version, last_heartbeat };
                }) : [];

                return {
                    ...lic,
                    device_names: deviceNames,
                    devices: deviceDetails
                };
            });

            return { licenses: formattedLicenses, total };
        } else {
            let list = [...memoryStore.licenses];
            if (search) {
                const s = search.toLowerCase();
                list = list.filter(l => {
                    const hasKey = l.license_key.toLowerCase().includes(s);
                    const hasCust = l.customer_name.toLowerCase().includes(s);
                    const acts = memoryStore.activations.filter(a => a.license_id === l.id);
                    const hasMachine = acts.some(a => a.machine_name && a.machine_name.toLowerCase().includes(s));
                    return hasKey || hasCust || hasMachine;
                });
            }
            if (status) list = list.filter(l => l.status === status);
            if (tier) list = list.filter(l => l.tier === tier);

            const paged = list.slice(offset, offset + limit).map(l => {
                const acts = memoryStore.activations.filter(a => a.license_id === l.id);
                return {
                    ...l,
                    device_names: acts.map(a => a.machine_name),
                    devices: acts
                };
            });

            return {
                licenses: paged,
                total: list.length
            };
        }
    }

    /**
     * Gets full license details including active devices and verification history.
     */
    static async getLicenseById(id) {
        const pool = getPool();
        let license = null;
        let activations = [];
        let logs = [];

        if (pool && getIsConnected()) {
            const [licRows] = await pool.query('SELECT * FROM `licenses` WHERE `id` = ?', [id]);
            if (licRows.length === 0) return null;
            license = licRows[0];

            const [actRows] = await pool.query('SELECT * FROM `license_activations` WHERE `license_id` = ? ORDER BY `last_heartbeat` DESC', [id]);
            activations = actRows;

            const [logRows] = await pool.query('SELECT * FROM `verification_logs` WHERE `license_key` = ? ORDER BY `timestamp` DESC LIMIT 50', [license.license_key]);
            logs = logRows;
        } else {
            license = memoryStore.licenses.find(l => l.id === parseInt(id, 10));
            if (!license) return null;
            activations = memoryStore.activations.filter(a => a.license_id === license.id);
            logs = memoryStore.logs.filter(lg => lg.license_key === license.license_key);
        }

        const decryptedPayload = CryptoService.decryptPayload(license.encrypted_payload);

        return {
            ...license,
            decrypted_metadata: decryptedPayload,
            activations,
            recent_logs: logs
        };
    }

    /**
     * Revokes a license immediately (Kill-Switch).
     */
    static async revokeLicense(id, reason = 'Administrative Revocation') {
        const pool = getPool();
        if (pool && getIsConnected()) {
            await pool.query('UPDATE `licenses` SET `status` = "revoked", `notes` = CONCAT(IFNULL(`notes`,""), " [Revoked: ", ?, "]") WHERE `id` = ?', [reason, id]);
        } else {
            const lic = memoryStore.licenses.find(l => l.id === parseInt(id, 10));
            if (lic) lic.status = 'revoked';
        }
        return { success: true, message: 'License has been revoked.' };
    }

    /**
     * Extends a license duration by N days.
     */
    static async extendLicense(id, additionalDays = 30) {
        const pool = getPool();
        const days = parseInt(additionalDays, 10);

        if (pool && getIsConnected()) {
            const [rows] = await pool.query('SELECT `expires_at`, `status` FROM `licenses` WHERE `id` = ?', [id]);
            if (rows.length === 0) throw new Error('License not found');

            const currentExpiry = new Date(rows[0].expires_at);
            const baseDate = currentExpiry > new Date() ? currentExpiry : new Date();
            const newExpiry = new Date(baseDate.getTime() + (days * 24 * 60 * 60 * 1000));

            await pool.query('UPDATE `licenses` SET `expires_at` = ?, `status` = "active" WHERE `id` = ?', [newExpiry, id]);
            return { success: true, new_expiry: newExpiry.toISOString() };
        } else {
            const lic = memoryStore.licenses.find(l => l.id === parseInt(id, 10));
            if (!lic) throw new Error('License not found');
            const baseDate = new Date(lic.expires_at) > new Date() ? new Date(lic.expires_at) : new Date();
            lic.expires_at = new Date(baseDate.getTime() + (days * 24 * 60 * 60 * 1000));
            lic.status = 'active';
            return { success: true, new_expiry: lic.expires_at.toISOString() };
        }
    }

    /**
     * Updates license status (active, expired, revoked, suspended).
     */
    static async updateStatus(id, newStatus) {
        const pool = getPool();
        if (pool && getIsConnected()) {
            await pool.query('UPDATE `licenses` SET `status` = ? WHERE `id` = ?', [newStatus, id]);
        } else {
            const lic = memoryStore.licenses.find(l => l.id === parseInt(id, 10));
            if (lic) lic.status = newStatus;
        }
    }

    /**
     * Deletes a license.
     */
    static async deleteLicense(id) {
        const pool = getPool();
        if (pool && getIsConnected()) {
            await pool.query('DELETE FROM `licenses` WHERE `id` = ?', [id]);
        } else {
            memoryStore.licenses = memoryStore.licenses.filter(l => l.id !== parseInt(id, 10));
            memoryStore.activations = memoryStore.activations.filter(a => a.license_id !== parseInt(id, 10));
        }
        return { success: true };
    }

    /**
     * Logs client verification attempts for audit and live telemetry.
     */
    static async logVerification(licenseKey, isValid, statusCode, machineName, ipAddress, clientVersion, message) {
        try {
            const pool = getPool();
            if (pool && getIsConnected()) {
                await pool.query(
                    'INSERT INTO `verification_logs` (`license_key`, `is_valid`, `status_code`, `machine_name`, `ip_address`, `client_version`, `message`) VALUES (?, ?, ?, ?, ?, ?, ?)',
                    [licenseKey, isValid ? 1 : 0, statusCode, machineName, ipAddress, clientVersion, message]
                );
            } else {
                memoryStore.logs.unshift({
                    id: memoryStore.logs.length + 1,
                    license_key: licenseKey,
                    is_valid: isValid,
                    status_code: statusCode,
                    machine_name: machineName,
                    ip_address: ipAddress,
                    client_version: clientVersion,
                    message: message,
                    timestamp: new Date()
                });
                if (memoryStore.logs.length > 500) memoryStore.logs.pop();
            }
        } catch (e) {
            console.error('[LicenseService] logVerification error:', e.message);
        }
    }

    /**
     * Gets global system statistics and telemetry dashboard counters.
     */
    static async getTelemetrySummary() {
        const pool = getPool();
        const now = new Date();

        if (pool && getIsConnected()) {
            const [[totalLic]] = await pool.query('SELECT COUNT(*) AS count FROM `licenses`');
            const [[activeLic]] = await pool.query('SELECT COUNT(*) AS count FROM `licenses` WHERE `status` = "active" AND `expires_at` > NOW()');
            const [[expiredLic]] = await pool.query('SELECT COUNT(*) AS count FROM `licenses` WHERE `status` = "expired" OR `expires_at` <= NOW()');
            const [[revokedLic]] = await pool.query('SELECT COUNT(*) AS count FROM `licenses` WHERE `status` = "revoked"');
            const [[totalAct]] = await pool.query('SELECT COUNT(*) AS count FROM `license_activations`');
            const [[validLogs]] = await pool.query('SELECT COUNT(*) AS count FROM `verification_logs` WHERE `is_valid` = 1');
            const [[failedLogs]] = await pool.query('SELECT COUNT(*) AS count FROM `verification_logs` WHERE `is_valid` = 0');
            const [recentLogs] = await pool.query('SELECT * FROM `verification_logs` ORDER BY `timestamp` DESC LIMIT 15');

            return {
                total_licenses: totalLic.count,
                active_licenses: activeLic.count,
                expired_licenses: expiredLic.count,
                revoked_licenses: revokedLic.count,
                total_device_activations: totalAct.count,
                total_verifications: validLogs.count + failedLogs.count,
                successful_verifications: validLogs.count,
                failed_verifications: failedLogs.count,
                recent_logs: recentLogs
            };
        } else {
            const total = memoryStore.licenses.length;
            const active = memoryStore.licenses.filter(l => l.status === 'active' && new Date(l.expires_at) > now).length;
            const expired = memoryStore.licenses.filter(l => l.status === 'expired' || new Date(l.expires_at) <= now).length;
            const revoked = memoryStore.licenses.filter(l => l.status === 'revoked').length;

            return {
                total_licenses: total,
                active_licenses: active,
                expired_licenses: expired,
                revoked_licenses: revoked,
                total_device_activations: memoryStore.activations.length,
                total_verifications: memoryStore.logs.length,
                successful_verifications: memoryStore.logs.filter(l => l.is_valid).length,
                failed_verifications: memoryStore.logs.filter(l => !l.is_valid).length,
                recent_logs: memoryStore.logs.slice(0, 15)
            };
        }
    }

    /**
     * Clears verification audit logs from database and memory store.
     */
    static async clearVerificationLogs() {
        const pool = getPool();
        if (pool && getIsConnected()) {
            await pool.query('DELETE FROM `verification_logs`');
        }
        memoryStore.logs = [];
        return { success: true, message: 'Verification audit stream cleared.' };
    }
}

module.exports = LicenseService;
