// CBN TECH License Controller Frontend Client - Ultra-Premium Executive Edition
const API_BASE = '/api/admin';
const VERIFY_API = '/api/verify-license';
const ADMIN_API_KEY = localStorage.getItem('dpms_admin_key') || 'DPMS-ADMIN-SECRET-KEY-9988';

let allLicenses = [];
let telemetryLogs = [];
let telemetryInterval = null;
let autoScrollLogs = true;
let currentLogFilter = 'ALL';
let currentQuickFilter = 'all';
let generatedLicenseCache = null;
let audioEnabled = localStorage.getItem('dpms_audio_enabled') !== 'false'; // Default ON

/**
 * Universal authenticated fetch helper for Admin endpoints.
 */
async function adminFetch(url, options = {}) {
    const headers = {
        'Content-Type': 'application/json',
        'X-Admin-Key': ADMIN_API_KEY,
        ...(options.headers || {})
    };
    return fetch(url, { ...options, headers });
}

document.addEventListener('DOMContentLoaded', () => {
    initClock();
    initKeyboardShortcuts();
    initAudioUI();
    loadDashboard();
    telemetryInterval = setInterval(loadTelemetry, 4000);
});

// Real-time Dual Clock (UTC + Local)
function initClock() {
    const clockEl = document.getElementById('txtLiveClock');
    const update = () => {
        const d = new Date();
        const utcStr = d.toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
        if (clockEl) clockEl.textContent = utcStr;
    };
    update();
    setInterval(update, 1000);
}

// Sound Synthesizer for Executive Haptic Feel (Web Audio API)
let audioCtx = null;
function playUiSound(type = 'click') {
    if (!audioEnabled) return;
    try {
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }
        if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }

        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);

        const now = audioCtx.currentTime;

        if (type === 'click') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(800, now);
            osc.frequency.exponentialRampToValueAtTime(400, now + 0.05);
            gain.gain.setValueAtTime(0.04, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
            osc.start(now);
            osc.stop(now + 0.05);
        } else if (type === 'success') {
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(520, now);
            osc.frequency.setValueAtTime(780, now + 0.08);
            gain.gain.setValueAtTime(0.05, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
            osc.start(now);
            osc.stop(now + 0.2);
        } else if (type === 'error') {
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(280, now);
            osc.frequency.setValueAtTime(200, now + 0.1);
            gain.gain.setValueAtTime(0.06, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
            osc.start(now);
            osc.stop(now + 0.25);
        }
    } catch (e) {
        // Ignore audio errors on browsers with strict autoplay policies
    }
}

function initAudioUI() {
    const onIcon = document.getElementById('audioIconOn');
    const offIcon = document.getElementById('audioIconOff');
    if (onIcon && offIcon) {
        onIcon.style.display = audioEnabled ? 'block' : 'none';
        offIcon.style.display = audioEnabled ? 'none' : 'block';
    }
}

function toggleAudioFeedback() {
    audioEnabled = !audioEnabled;
    localStorage.setItem('dpms_audio_enabled', audioEnabled);
    initAudioUI();
    if (audioEnabled) {
        playUiSound('success');
        showToast('🔊 Audio feedback enabled', 'info');
    } else {
        showToast('🔇 Audio feedback muted', 'info');
    }
}

// Global Keyboard Shortcuts
function initKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        const isInput = ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName);
        
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
            e.preventDefault();
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.focus();
                searchInput.select();
            }
            return;
        }

        if (e.key === 'Escape') {
            closeAllModals();
            return;
        }

        if (!isInput) {
            if (e.key === '/') {
                e.preventDefault();
                const searchInput = document.getElementById('searchInput');
                if (searchInput) searchInput.focus();
            } else if (e.key.toLowerCase() === 'n') {
                e.preventDefault();
                openGenerateModal();
            } else if (e.key.toLowerCase() === 'b') {
                e.preventDefault();
                openBatchModal();
            } else if (e.key.toLowerCase() === 't') {
                e.preventDefault();
                openTesterModal();
            } else if (e.key.toLowerCase() === 'r') {
                e.preventDefault();
                loadDashboard();
                showToast('🔄 Synchronized dashboard with database', 'info');
            } else if (e.key === '?') {
                e.preventDefault();
                openShortcutsModal();
            }
        }
    });
}

function handleModalOverlayClick(e, modalId) {
    if (e.target && e.target.id === modalId) {
        closeAllModals();
    }
}

function closeAllModals() {
    closeGenerateModal();
    closeBatchModal();
    closeResultModal();
    closeDetailsModal();
    closeTesterModal();
    closeShortcutsModal();
}

function openShortcutsModal() {
    playUiSound('click');
    document.getElementById('shortcutsModal').classList.add('active');
}
function closeShortcutsModal() {
    document.getElementById('shortcutsModal').classList.remove('active');
}

async function loadDashboard() {
    playUiSound('click');
    await Promise.all([
        loadLicenses(),
        loadTelemetry()
    ]);
}

/**
 * Loads licenses with live search, tier, and status filtering.
 */
async function loadLicenses() {
    try {
        const searchInput = document.getElementById('searchInput');
        const statusFilter = document.getElementById('statusFilter');
        const tierFilter = document.getElementById('tierFilter');

        const search = searchInput ? searchInput.value.trim() : '';
        let status = statusFilter ? statusFilter.value : '';
        let tier = tierFilter ? tierFilter.value : '';

        // Apply quick filter override if set
        if (currentQuickFilter === 'active') status = 'active';
        else if (currentQuickFilter === 'revoked') status = 'revoked';
        else if (currentQuickFilter === 'enterprise') tier = 'Enterprise';

        const params = new URLSearchParams();
        if (search) params.append('search', search);
        if (status) params.append('status', status);
        if (tier) params.append('tier', tier);

        const res = await adminFetch(`${API_BASE}/licenses?${params.toString()}`);
        const data = await res.json();

        if (data.success) {
            allLicenses = data.licenses || [];
            
            // If expiring filter is chosen, filter in-memory for <= 30 days
            let displayList = allLicenses;
            if (currentQuickFilter === 'expiring') {
                const now = new Date();
                const thirtyDays = 30 * 24 * 60 * 60 * 1000;
                displayList = allLicenses.filter(l => {
                    const diff = new Date(l.expires_at) - now;
                    return diff > 0 && diff <= thirtyDays && l.status === 'active';
                });
            }

            renderLicenses(displayList);
            updateQuickFilterCounts(allLicenses);
            
            const badge = document.getElementById('licenseCountBadge');
            if (badge) badge.textContent = `${displayList.length} records`;

            const summary = document.getElementById('tableSummaryText');
            if (summary) summary.textContent = `Showing ${displayList.length} of ${data.total || allLicenses.length} licensed records`;
        }
    } catch (error) {
        console.error('Failed to load licenses:', error);
        showToast('⚠ Failed to connect to cryptographic license ledger', 'error');
    }
}

/**
 * Quick Filter Chips Bar Selector
 */
function setQuickFilter(filter) {
    playUiSound('click');
    currentQuickFilter = filter;

    document.querySelectorAll('.quick-pill').forEach(btn => {
        btn.classList.remove('active');
        if (btn.getAttribute('data-filter') === filter) {
            btn.classList.add('active');
        }
    });

    const statusFilter = document.getElementById('statusFilter');
    const tierFilter = document.getElementById('tierFilter');

    if (filter === 'active' && statusFilter) statusFilter.value = 'active';
    else if (filter === 'expired' && statusFilter) statusFilter.value = 'expired';
    else if (filter === 'revoked' && statusFilter) statusFilter.value = 'revoked';
    else if (filter === 'enterprise' && tierFilter) tierFilter.value = 'Enterprise';
    else if (filter === 'all') {
        if (statusFilter) statusFilter.value = '';
        if (tierFilter) tierFilter.value = '';
    }

    loadLicenses();
}

function updateQuickFilterCounts(licenses) {
    const now = new Date();
    const thirtyDays = 30 * 24 * 60 * 60 * 1000;

    let activeCount = 0;
    let expiringCount = 0;
    let revokedCount = 0;

    licenses.forEach(l => {
        const isExp = new Date(l.expires_at) < now;
        const diff = new Date(l.expires_at) - now;
        
        if (l.status === 'revoked') {
            revokedCount++;
        } else if (l.status === 'active' && !isExp) {
            activeCount++;
            if (diff > 0 && diff <= thirtyDays) {
                expiringCount++;
            }
        }
    });

    const elAll = document.getElementById('chipCountAll');
    const elActive = document.getElementById('chipCountActive');
    const elExp = document.getElementById('chipCountExpiring');
    const elRev = document.getElementById('chipCountRevoked');

    if (elAll) elAll.textContent = licenses.length;
    if (elActive) elActive.textContent = activeCount;
    if (elExp) elExp.textContent = expiringCount;
    if (elRev) elRev.textContent = revokedCount;
}

/**
 * Renders the license table rows, including device names & workstation chips.
 */
function renderLicenses(licenses) {
    const tbody = document.getElementById('licensesTableBody');
    if (!tbody) return;

    if (!licenses || licenses.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="table-empty-row">
                    <div class="empty-state-icon">🛡️</div>
                    <div style="font-weight: 700; color: var(--text-primary); margin-bottom: 4px;">No Matching License Records Found</div>
                    <div style="font-size: 11.5px; color: var(--text-muted);">Click "+ Generate Key" to issue a new cryptographic key or adjust your filter.</div>
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = licenses.map(lic => {
        const expiryDate = new Date(lic.expires_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
        const isExp = new Date(lic.expires_at) < new Date();
        const effectiveStatus = isExp && lic.status === 'active' ? 'expired' : lic.status;

        // Relative days calculation
        const diffDays = Math.ceil((new Date(lic.expires_at) - new Date()) / (1000 * 60 * 60 * 24));
        let relativeExpiryText = '';
        let relativeClass = '';
        if (diffDays > 30) {
            relativeExpiryText = `in ${diffDays} days`;
        } else if (diffDays > 0) {
            relativeExpiryText = `expires in ${diffDays}d ⚠️`;
            relativeClass = 'text-amber';
        } else {
            relativeExpiryText = `expired ${Math.abs(diffDays)}d ago`;
            relativeClass = 'text-rose';
        }

        // Customer initials avatar
        const initials = getCustomerInitials(lic.customer_name);

        // Tier Class
        const tierLower = (lic.tier || 'enterprise').toLowerCase();
        const tierClass = `tier-${tierLower}`;
        const tierIcon = tierLower === 'enterprise' ? '👑' : (tierLower === 'standard' ? '⚡' : (tierLower === 'trial' ? '🧪' : '🛠️'));

        // Format Workstations / Device Names
        const devicesHtml = renderDeviceNamesCell(lic);

        return `
            <tr>
                <!-- 1. License Key Column -->
                <td>
                    <div class="key-badge-container">
                        <span class="key-badge mono" title="${escapeHtml(lic.license_key)}">${escapeHtml(lic.license_key)}</span>
                        <button class="btn-inline-copy" id="btnCopy_${lic.id}" onclick="copyKey('${escapeHtml(lic.license_key)}', this)" title="Copy License Key">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                        </button>
                    </div>
                </td>

                <!-- 2. Customer / Entity Column -->
                <td>
                    <div class="customer-cell">
                        <div class="customer-avatar">${initials}</div>
                        <div class="customer-details">
                            <span class="customer-name" title="${escapeHtml(lic.customer_name)}">${escapeHtml(lic.customer_name)}</span>
                            ${lic.customer_email ? `<span class="customer-email" title="${escapeHtml(lic.customer_email)}">${escapeHtml(lic.customer_email)}</span>` : '<span class="customer-email text-muted">No email registered</span>'}
                        </div>
                    </div>
                </td>

                <!-- 3. Tier Column -->
                <td>
                    <span class="tier-badge ${tierClass}">
                        <span>${tierIcon}</span>
                        <span>${escapeHtml(lic.tier || 'Enterprise')}</span>
                    </span>
                </td>

                <!-- 4. BOUND WORKSTATIONS / DEVICE NAME -->
                <td>
                    ${devicesHtml}
                </td>

                <!-- 5. Status Column -->
                <td>
                    <span class="status-pill ${effectiveStatus}">
                        <span class="status-dot"></span>
                        <span>${effectiveStatus}</span>
                    </span>
                </td>

                <!-- 6. Expiration Column -->
                <td>
                    <div class="expiry-cell">
                        <span class="expiry-date mono">${expiryDate}</span>
                        <span class="expiry-relative mono ${relativeClass}">${relativeExpiryText}</span>
                    </div>
                </td>

                <!-- 7. Actions Column -->
                <td style="text-align: right;">
                    <div class="table-action-btns">
                        <button class="btn-table-action action-details" onclick="openLicenseDetails(${lic.id})" title="Inspect Devices &amp; Hardware Audit">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                        </button>
                        <button class="btn-table-action action-extend" onclick="extendLicense(${lic.id})" title="Extend License (+30 Days / Custom)">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/><path d="M16 10h4M18 8v4"/></svg>
                        </button>
                        <button class="btn-table-action" onclick="openTesterModal('${escapeHtml(lic.license_key)}')" title="Test in Sandbox">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                        </button>
                        ${lic.status !== 'revoked' ? `
                            <button class="btn-table-action action-revoke" onclick="revokeLicense(${lic.id})" title="Trigger Kill-Switch (Revoke)">
                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
                            </button>
                        ` : ''}
                        <button class="btn-table-action action-delete" onclick="deleteLicense(${lic.id})" title="Delete License Record">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

/**
 * Renders the Device Names cell with active chips and quota counters.
 */
function renderDeviceNamesCell(lic) {
    const max = lic.max_activations === 0 ? '∞' : lic.max_activations;
    const current = lic.current_activations || 0;
    
    // Get device names list
    let deviceList = [];
    if (Array.isArray(lic.devices) && lic.devices.length > 0) {
        deviceList = lic.devices;
    } else if (Array.isArray(lic.device_names) && lic.device_names.length > 0) {
        deviceList = lic.device_names.map(name => ({ machine_name: name }));
    }

    const quotaHeader = `
        <div class="device-quota-header">
            <span class="device-quota-badge mono">${current} / ${max} Nodes</span>
        </div>
    `;

    if (deviceList.length === 0) {
        return `
            <div class="devices-container">
                ${quotaHeader}
                <div class="device-chip-empty" title="Awaiting first client connection from WPF Kiosk">
                    <span class="dot-unbound"></span>
                    <span>No device registered yet</span>
                </div>
            </div>
        `;
    }

    // Render up to 3 device name chips, then show +N more if extra
    const visibleDevices = deviceList.slice(0, 3);
    const hiddenCount = deviceList.length - visibleDevices.length;

    const chipsHtml = visibleDevices.map(d => {
        const name = d.machine_name || 'UNKNOWN-DEVICE';
        const ip = d.ip_address ? ` | IP: ${d.ip_address}` : '';
        const ver = d.client_version ? ` | v${d.client_version}` : '';
        return `
            <div class="device-chip" title="Workstation: ${escapeHtml(name)}${escapeHtml(ip)}${escapeHtml(ver)}">
                <span class="device-dot-active"></span>
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
                <span class="mono">${escapeHtml(name)}</span>
            </div>
        `;
    }).join('');

    const moreHtml = hiddenCount > 0 ? `
        <span class="device-more-chip" onclick="openLicenseDetails(${lic.id})" title="View all ${deviceList.length} bound devices">
            +${hiddenCount} more
        </span>
    ` : '';

    return `
        <div class="devices-container">
            ${quotaHeader}
            <div class="device-chips-list">
                ${chipsHtml}
                ${moreHtml}
            </div>
        </div>
    `;
}

function getCustomerInitials(name) {
    if (!name) return 'DP';
    const words = name.trim().split(/\s+/);
    if (words.length === 1) {
        return words[0].substring(0, 2).toUpperCase();
    }
    return (words[0][0] + words[1][0]).toUpperCase();
}

let terminalClearedAt = 0;

/**
 * Loads live telemetry counters and verification stream.
 */
async function loadTelemetry() {
    try {
        const startTime = performance.now();
        const res = await adminFetch(`${API_BASE}/telemetry`);
        const elapsed = Math.round(performance.now() - startTime);
        const data = await res.json();

        // Update Latency Badge
        const latencyEl = document.getElementById('txtLatency');
        if (latencyEl) {
            latencyEl.textContent = `${elapsed}ms`;
        }

        if (data.success && data.telemetry) {
            const t = data.telemetry;
            
            // Update Stat Values with smooth transition
            animateValue('statTotalLicenses', t.total_licenses || 0);
            animateValue('statActiveLicenses', t.active_licenses || 0);
            animateValue('statExpiredLicenses', t.expired_licenses || 0);
            animateValue('statRevokedLicenses', t.revoked_licenses || 0);
            animateValue('statActivations', t.total_device_activations || 0);
            animateValue('statVerifications', t.total_verifications || 0);

            // Update Progress Bar ratios
            const total = t.total_licenses || 1;
            const activePct = Math.round(((t.active_licenses || 0) / total) * 100);
            const expPct = Math.round(((t.expired_licenses || 0) / total) * 100);
            const revPct = Math.round(((t.revoked_licenses || 0) / total) * 100);

            const barActive = document.getElementById('barActiveLicenses');
            const barExp = document.getElementById('barExpiredLicenses');
            const barRev = document.getElementById('barRevokedLicenses');

            if (barActive) barActive.style.width = `${activePct}%`;
            if (barExp) barExp.style.width = `${expPct}%`;
            if (barRev) barRev.style.width = `${revPct}%`;

            const rawLogs = t.recent_logs || [];
            if (terminalClearedAt > 0) {
                telemetryLogs = rawLogs.filter(l => new Date(l.timestamp).getTime() > terminalClearedAt);
            } else {
                telemetryLogs = rawLogs;
            }
            renderLogs(telemetryLogs);
        }
    } catch (e) {
        console.error('Telemetry error:', e);
    }
}

function animateValue(elementId, value) {
    const el = document.getElementById(elementId);
    if (!el) return;
    el.textContent = value;
}

/**
 * Renders the live telemetry logs terminal stream with filtering.
 */
function renderLogs(logs) {
    const container = document.getElementById('terminalLogs');
    const counter = document.getElementById('streamCounter');
    if (!container) return;

    let filtered = logs || [];
    if (currentLogFilter === 'VALID') {
        filtered = filtered.filter(l => l.is_valid);
    } else if (currentLogFilter === 'DENIED') {
        filtered = filtered.filter(l => !l.is_valid);
    }

    if (counter) {
        counter.textContent = `${filtered.length} event${filtered.length === 1 ? '' : 's'} captured`;
    }

    if (!filtered || filtered.length === 0) {
        container.innerHTML = `
            <div class="log-line log-system">
                <span class="log-time">[ LIVE ]</span>
                <span class="log-badge badge-cyan">LISTENER</span>
                <span class="log-msg">Stream active. Waiting for client verification requests...</span>
            </div>
        `;
        return;
    }

    container.innerHTML = filtered.map(log => {
        const time = new Date(log.timestamp).toLocaleTimeString();
        const isSuccess = log.is_valid;
        const statusClass = isSuccess ? 'log-success' : 'log-error';
        const badgeClass = isSuccess ? 'badge-emerald' : 'badge-rose';
        const keySnippet = log.license_key ? log.license_key.substring(0, 14) + '...' : 'ANONYMOUS_KEY';
        const machine = log.machine_name || 'UNKNOWN-WORKSTATION';
        const ip = log.ip_address || '127.0.0.1';

        return `
            <div class="log-line ${statusClass}">
                <div class="log-top-row">
                    <span class="log-time">[${time}]</span>
                    <span class="log-badge ${badgeClass}">${escapeHtml(log.status_code || 'VERIFY')}</span>
                    <span class="log-machine" title="Workstation Device Name">💻 ${escapeHtml(machine)}</span>
                    <span class="log-ip">${escapeHtml(ip)}</span>
                </div>
                <div class="log-msg">
                    Key: <code class="mono" style="color: var(--cyan-accent);">${escapeHtml(keySnippet)}</code> &bull; ${escapeHtml(log.message || '')}
                </div>
            </div>
        `;
    }).join('');

    if (autoScrollLogs) {
        container.scrollTop = container.scrollHeight;
    }
}

function toggleAutoScroll() {
    playUiSound('click');
    autoScrollLogs = !autoScrollLogs;
    const btn = document.getElementById('btnToggleAutoScroll');
    if (btn) {
        btn.classList.toggle('active', autoScrollLogs);
    }
    showToast(autoScrollLogs ? 'Auto-scroll enabled' : 'Auto-scroll paused', 'info');
}

async function clearLogs() {
    playUiSound('click');
    terminalClearedAt = Date.now();
    telemetryLogs = [];
    renderLogs([]);

    try {
        await adminFetch(`${API_BASE}/telemetry/logs`, { method: 'DELETE' });
    } catch (e) {
        console.warn('Failed to clear logs on server:', e);
    }

    showToast('✓ Terminal audit stream cleared', 'info');
}

function filterLogs(filter) {
    playUiSound('click');
    currentLogFilter = filter;
    document.querySelectorAll('.term-filter-pill').forEach(btn => {
        btn.classList.remove('active');
    });
    if (event && event.target) {
        event.target.classList.add('active');
    }
    renderLogs(telemetryLogs);
}

// Search Debounce with Clear Button support
let searchTimeout;
function handleSearch() {
    const input = document.getElementById('searchInput');
    const clearBtn = document.getElementById('searchClearBtn');
    if (clearBtn) {
        clearBtn.style.display = input && input.value.trim() ? 'block' : 'none';
    }
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(loadLicenses, 180);
}

function clearSearch() {
    playUiSound('click');
    const input = document.getElementById('searchInput');
    const clearBtn = document.getElementById('searchClearBtn');
    if (input) input.value = '';
    if (clearBtn) clearBtn.style.display = 'none';
    loadLicenses();
}

// Live Key Generator Preview
function updateLivePreview() {
    const prefix = document.getElementById('genPrefix').value.trim() || 'CBN';
    const previewEl = document.getElementById('liveKeyPreview');
    if (previewEl) {
        previewEl.textContent = `${prefix.toUpperCase()}-XXXX-XXXX-XXXX-XXXX`;
    }
}

// Preset Template Definitions
const GENERATE_PRESETS = {
    'enterprise-1yr': {
        name: 'Enterprise Port Kiosk Fleet',
        email: 'admin@darlingport.com',
        prefix: 'CBN',
        tier: 'Enterprise',
        duration: '365',
        maxDevices: '5',
        notes: 'Production Multi-Kiosk Port Fleet (High-Availability)',
        features: { kiosk: true, tls: true, multiUser: true, offline: true }
    },
    'trial-60d': {
        name: 'Pilot Evaluation Terminal',
        email: 'eval@portlogistics.org',
        prefix: 'TRIAL',
        tier: 'Trial',
        duration: '60',
        maxDevices: '1',
        notes: '60-Day Proof-of-Concept Evaluation Gate Terminal',
        features: { kiosk: true, tls: true, multiUser: false, offline: false }
    },
    'standard-ops': {
        name: 'Standard Gate Operator Desk',
        email: 'ops@harbortraffic.com',
        prefix: 'STD',
        tier: 'Standard',
        duration: '365',
        maxDevices: '2',
        notes: 'Standard Dual-Operator Terminal Station',
        features: { kiosk: true, tls: true, multiUser: true, offline: false }
    },
    'dev-sandbox': {
        name: 'Developer Sandbox Enclave',
        email: 'dev@sandbox.local',
        prefix: 'DEV',
        tier: 'Developer',
        duration: '36500',
        maxDevices: '0',
        notes: 'Unrestricted Core Developer & QA Integration Sandbox',
        features: { kiosk: true, tls: true, multiUser: true, offline: true }
    },
    'lifetime-master': {
        name: 'Perpetual Air-Gapped Master',
        email: 'secops@defensemaritime.gov',
        prefix: 'MAST',
        tier: 'Enterprise',
        duration: '36500',
        maxDevices: '25',
        notes: 'Permanent Offline Master Enclave Deployment',
        features: { kiosk: true, tls: true, multiUser: true, offline: true }
    }
};

const BATCH_PRESETS = {
    'fleet-10-ent': {
        count: 10,
        tag: 'Terminal Kiosk Fleet Production',
        tier: 'Enterprise',
        days: 365
    },
    'trial-5-eval': {
        count: 5,
        tag: 'Pilot Evaluation Batch',
        tier: 'Trial',
        days: 60
    },
    'standard-20-ops': {
        count: 20,
        tag: 'Regional Gate Operator Desks',
        tier: 'Standard',
        days: 365
    }
};

// Quick Presets inside Generate Modal
function applyPreset(presetKey) {
    playUiSound('click');
    const p = GENERATE_PRESETS[presetKey];
    if (!p) return;

    const nameInput = document.getElementById('genCustomerName');
    const emailInput = document.getElementById('genEmail');
    const prefixInput = document.getElementById('genPrefix');
    const tierInput = document.getElementById('genTier');
    const durationInput = document.getElementById('genDuration');
    const maxDevInput = document.getElementById('genMaxDevices');
    const notesInput = document.getElementById('genNotes');

    const featKiosk = document.getElementById('featKiosk');
    const featTls = document.getElementById('featTls');
    const featMultiUser = document.getElementById('featMultiUser');
    const featOffline = document.getElementById('featOffline');

    if (nameInput) nameInput.value = p.name;
    if (emailInput) emailInput.value = p.email;
    if (prefixInput) prefixInput.value = p.prefix;
    if (tierInput) tierInput.value = p.tier;
    if (durationInput) durationInput.value = p.duration;
    if (maxDevInput) maxDevInput.value = p.maxDevices;
    if (notesInput) notesInput.value = p.notes;

    if (featKiosk) featKiosk.checked = !!p.features.kiosk;
    if (featTls) featTls.checked = !!p.features.tls;
    if (featMultiUser) featMultiUser.checked = !!p.features.multiUser;
    if (featOffline) featOffline.checked = !!p.features.offline;

    // Highlight active preset button
    document.querySelectorAll('#generateModal .preset-pill').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-preset') === presetKey);
    });

    updateLivePreview();
    showToast(`✓ Applied template: ${p.name}`, 'info');
}

// Quick Presets inside Batch Modal
function applyBatchPreset(presetKey) {
    playUiSound('click');
    const p = BATCH_PRESETS[presetKey];
    if (!p) return;

    const countInput = document.getElementById('batchCount');
    const tagInput = document.getElementById('batchClientTag');
    const tierInput = document.getElementById('batchTier');
    const daysInput = document.getElementById('batchDays');

    if (countInput) countInput.value = p.count;
    if (tagInput) tagInput.value = p.tag;
    if (tierInput) tierInput.value = p.tier;
    if (daysInput) daysInput.value = p.days;

    document.querySelectorAll('#batchModal .preset-pill').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-batch-preset') === presetKey);
    });

    showToast(`✓ Applied batch template: ${p.tag}`, 'info');
}

// Modals Controls
function openGenerateModal() {
    playUiSound('click');
    document.getElementById('generateModal').classList.add('active');
    updateLivePreview();
    setTimeout(() => {
        const nameInput = document.getElementById('genCustomerName');
        if (nameInput) nameInput.focus();
    }, 100);
}
function closeGenerateModal() {
    document.getElementById('generateModal').classList.remove('active');
}

function openBatchModal() {
    playUiSound('click');
    document.getElementById('batchModal').classList.add('active');
}
function closeBatchModal() {
    document.getElementById('batchModal').classList.remove('active');
}

function closeResultModal() {
    document.getElementById('resultModal').classList.remove('active');
}

function closeDetailsModal() {
    document.getElementById('detailsModal').classList.remove('active');
}

function openTesterModal(prefillKey = '') {
    playUiSound('click');
    document.getElementById('testerModal').classList.add('active');
    if (prefillKey) {
        document.getElementById('testLicenseKey').value = prefillKey;
    }
}
function closeTesterModal() {
    document.getElementById('testerModal').classList.remove('active');
}

function pasteFirstLicenseKey() {
    if (allLicenses && allLicenses.length > 0) {
        document.getElementById('testLicenseKey').value = allLicenses[0].license_key;
        showToast(`📋 Pasted key: ${allLicenses[0].license_key}`, 'info');
    }
}

// Generate License Submission
async function handleGenerate(e) {
    e.preventDefault();
    const btn = document.getElementById('btnSubmitGenerate');
    btn.disabled = true;
    btn.innerHTML = `<span class="loading-spinner" style="width: 14px; height: 14px; margin: 0;"></span> <span>Encrypting Key...</span>`;

    // Collect features
    const features = [];
    if (document.getElementById('featKiosk').checked) features.push('kiosk_hardening');
    if (document.getElementById('featTls').checked) features.push('tls_encryption');
    if (document.getElementById('featMultiUser').checked) features.push('terminal_desk');
    if (document.getElementById('featOffline').checked) features.push('offline_fallback');

    const payload = {
        customer_name: document.getElementById('genCustomerName').value.trim(),
        customer_email: document.getElementById('genEmail').value.trim(),
        tier: document.getElementById('genTier').value,
        days_valid: parseInt(document.getElementById('genDuration').value, 10),
        max_activations: parseInt(document.getElementById('genMaxDevices').value, 10),
        prefix: document.getElementById('genPrefix').value.trim() || 'CBN',
        notes: document.getElementById('genNotes').value.trim(),
        custom_features: features
    };

    try {
        const res = await adminFetch(`${API_BASE}/licenses/generate`, {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        const data = await res.json();

        if (data.success && data.license) {
            playUiSound('success');
            closeGenerateModal();
            showResult(data.license);
            loadDashboard();
            showToast('✓ Cryptographic license issued successfully!', 'success');
        } else {
            playUiSound('error');
            showToast(`⚠ Generation error: ${data.message}`, 'error');
        }
    } catch (error) {
        playUiSound('error');
        showToast(`⚠ Request failed: ${error.message}`, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg> <span>Generate &amp; Store Key</span>`;
    }
}

// Batch Generate Submission
async function handleBatchGenerate(e) {
    e.preventDefault();
    const btn = document.getElementById('btnBatchSubmit');
    btn.disabled = true;
    btn.textContent = 'Issuing Batch...';

    const payload = {
        count: parseInt(document.getElementById('batchCount').value, 10),
        customer_name: document.getElementById('batchClientTag').value.trim(),
        tier: document.getElementById('batchTier').value,
        days_valid: parseInt(document.getElementById('batchDays').value, 10),
        prefix: 'CBN'
    };

    try {
        const res = await adminFetch(`${API_BASE}/licenses/batch-generate`, {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        const data = await res.json();

        if (data.success) {
            playUiSound('success');
            closeBatchModal();
            loadDashboard();
            showToast(`✓ Generated fleet of ${data.count} licenses!`, 'success');
        } else {
            playUiSound('error');
            showToast(`⚠ Batch error: ${data.message}`, 'error');
        }
    } catch (error) {
        playUiSound('error');
        showToast(`⚠ Request failed: ${error.message}`, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = 'Generate Batch';
    }
}

function showResult(license) {
    generatedLicenseCache = license;
    document.getElementById('resultKeyText').value = license.license_key;
    document.getElementById('resCustomer').textContent = license.customer_name;
    document.getElementById('resTier').textContent = license.tier;
    document.getElementById('resExpiry').textContent = new Date(license.expires_at).toLocaleDateString();
    document.getElementById('resDevices').textContent = `${license.max_activations === 0 ? 'Unlimited' : license.max_activations} Devices`;
    
    // Draw dynamic QR Code on canvas
    drawQrMatrix(license.license_key);

    document.getElementById('resultModal').classList.add('active');
}

/**
 * Lightweight Matrix QR Code Canvas Generator
 */
function drawQrMatrix(text) {
    const canvas = document.getElementById('qrCodeCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const size = 100;
    canvas.width = size;
    canvas.height = size;

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, size, size);

    // Draw high-tech 2D matrix pattern seeded from the key string
    ctx.fillStyle = '#050811';
    const grid = 15;
    const cellSize = size / grid;

    // Fixed corner squares
    const drawFinder = (x, y) => {
        ctx.fillRect(x * cellSize, y * cellSize, 3 * cellSize, 3 * cellSize);
        ctx.clearRect((x + 0.6) * cellSize, (y + 0.6) * cellSize, 1.8 * cellSize, 1.8 * cellSize);
        ctx.fillRect((x + 1) * cellSize, (y + 1) * cellSize, 1 * cellSize, 1 * cellSize);
    };

    drawFinder(1, 1);
    drawFinder(grid - 4, 1);
    drawFinder(1, grid - 4);

    let seed = 0;
    for (let i = 0; i < text.length; i++) {
        seed = (seed * 31 + text.charCodeAt(i)) % 1000000;
    }

    for (let r = 0; r < grid; r++) {
        for (let c = 0; c < grid; c++) {
            // Avoid corner finder areas
            if ((r <= 4 && c <= 4) || (r <= 4 && c >= grid - 5) || (r >= grid - 5 && c <= 4)) {
                continue;
            }
            seed = (seed * 1103515245 + 12345) % 2147483648;
            if ((seed % 100) > 48) {
                ctx.fillRect(c * cellSize, r * cellSize, cellSize - 0.5, cellSize - 0.5);
            }
        }
    }
}

function copyResultKey() {
    playUiSound('success');
    const input = document.getElementById('resultKeyText');
    input.select();
    navigator.clipboard.writeText(input.value);
    
    const btn = document.getElementById('btnCopyHero');
    if (btn) {
        const original = btn.innerHTML;
        btn.innerHTML = `✓ <span>Copied!</span>`;
        setTimeout(() => { btn.innerHTML = original; }, 2000);
    }
    showToast('📋 License Key copied to clipboard!', 'success');
}

function testCurrentGeneratedKey() {
    if (generatedLicenseCache) {
        closeResultModal();
        openTesterModal(generatedLicenseCache.license_key);
    }
}

function copyKey(key, btnEl) {
    playUiSound('success');
    navigator.clipboard.writeText(key);
    if (btnEl) {
        btnEl.classList.add('copied');
        const orig = btnEl.innerHTML;
        btnEl.innerHTML = `<span style="font-size: 11px; font-weight: 800; color: var(--emerald-accent);">✓</span>`;
        setTimeout(() => {
            btnEl.innerHTML = orig;
            btnEl.classList.remove('copied');
        }, 1800);
    }
    showToast(`📋 Copied: ${key}`, 'success');
}

function downloadLicenseFile() {
    if (!generatedLicenseCache) return;
    playUiSound('click');
    const licData = {
        license_key: generatedLicenseCache.license_key,
        customer: generatedLicenseCache.customer_name,
        tier: generatedLicenseCache.tier,
        expires_at: generatedLicenseCache.expires_at,
        max_activations: generatedLicenseCache.max_activations,
        issuer: "CBN TECH Cryptographic Server v2.4",
        format: "HMAC-SHA256"
    };

    const blob = new Blob([JSON.stringify(licData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `license-${generatedLicenseCache.license_key}.lic`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast('📥 Cryptographic license file downloaded', 'success');
}

// License Details & Workstations Audit Modal
async function openLicenseDetails(id) {
    playUiSound('click');
    const modal = document.getElementById('detailsModal');
    const body = document.getElementById('detailsBody');
    modal.classList.add('active');
    body.innerHTML = `<div class="loading-state"><div class="loading-spinner"></div><div>Loading hardware telemetry and device bindings...</div></div>`;

    try {
        const res = await adminFetch(`${API_BASE}/licenses/${id}`);
        const data = await res.json();

        if (data.success && data.license) {
            const lic = data.license;
            const acts = lic.activations || [];

            const activationsTable = acts.length > 0 ? `
                <table class="details-devices-table">
                    <thead>
                        <tr>
                            <th>WORKSTATION / DEVICE NAME</th>
                            <th>IP ADDRESS</th>
                            <th>CLIENT VERSION</th>
                            <th>FIRST ACTIVATED</th>
                            <th>LAST HEARTBEAT</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${acts.map(a => `
                            <tr>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 6px; font-weight: 700;">
                                        <span class="device-dot-active"></span>
                                        <span class="mono">${escapeHtml(a.machine_name)}</span>
                                    </div>
                                </td>
                                <td class="mono">${escapeHtml(a.ip_address || '127.0.0.1')}</td>
                                <td class="mono">v${escapeHtml(a.client_version || '1.0')}</td>
                                <td class="mono" style="font-size: 10.5px;">${new Date(a.first_activated_at).toLocaleString()}</td>
                                <td class="mono" style="font-size: 10.5px; color: var(--emerald-accent);">${new Date(a.last_heartbeat).toLocaleString()}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            ` : `<div class="device-chip-empty" style="padding: 12px;">No active device workstations currently bound to this license key.</div>`;

            body.innerHTML = `
                <div class="key-box-hero" style="margin-bottom: 0;">
                    <span class="key-box-label">CRYPTOGRAPHIC LICENSE KEY</span>
                    <div class="key-box-row">
                        <input type="text" value="${escapeHtml(lic.license_key)}" readonly class="key-input-hero mono">
                        <button class="btn btn-copy-hero" onclick="copyKey('${escapeHtml(lic.license_key)}')">Copy</button>
                    </div>
                </div>

                <div class="result-meta-cards">
                    <div class="meta-card">
                        <span class="meta-title">CUSTOMER</span>
                        <span class="meta-val">${escapeHtml(lic.customer_name)}</span>
                    </div>
                    <div class="meta-card">
                        <span class="meta-title">TIER</span>
                        <span class="meta-val">${escapeHtml(lic.tier)}</span>
                    </div>
                    <div class="meta-card">
                        <span class="meta-title">STATUS</span>
                        <span class="meta-val" style="text-transform: uppercase;">${escapeHtml(lic.status)}</span>
                    </div>
                    <div class="meta-card">
                        <span class="meta-title">EXPIRES AT</span>
                        <span class="meta-val">${new Date(lic.expires_at).toLocaleDateString()}</span>
                    </div>
                </div>

                <div>
                    <h4 class="details-section-title">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
                        BOUND CLIENT WORKSTATIONS (${acts.length} / ${lic.max_activations === 0 ? '∞' : lic.max_activations})
                    </h4>
                    ${activationsTable}
                </div>

                <div>
                    <h4 class="details-section-title">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                        DECRYPTED METADATA PAYLOAD (AES-256-GCM)
                    </h4>
                    <pre class="response-json-box mono">${escapeHtml(JSON.stringify(lic.decrypted_metadata || {}, null, 2))}</pre>
                </div>
            `;
        }
    } catch (e) {
        body.innerHTML = `<div class="log-line log-error">Failed to load license details: ${escapeHtml(e.message)}</div>`;
    }
}

// Sandbox API Verification Tester
async function handleTestVerification(e) {
    e.preventDefault();
    const btn = document.getElementById('btnRunTest');
    const key = document.getElementById('testLicenseKey').value.trim();
    const machine = document.getElementById('testMachineName').value.trim();
    const version = document.getElementById('testClientVersion').value.trim();
    const responseArea = document.getElementById('testerResponseArea');
    const statusPill = document.getElementById('testStatusPill');
    const latencyEl = document.getElementById('testLatency');
    const outputJson = document.getElementById('testJsonOutput');

    btn.disabled = true;
    btn.textContent = 'Simulating...';

    const startTime = performance.now();

    try {
        const res = await fetch(VERIFY_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                key,
                machine_name: machine,
                client_version: version
            })
        });

        const elapsed = Math.round(performance.now() - startTime);
        const data = await res.json();

        responseArea.style.display = 'block';
        latencyEl.textContent = `${elapsed}ms`;

        if (data.valid) {
            playUiSound('success');
            statusPill.textContent = `STATUS 200 OK • VERIFIED VALID`;
            statusPill.style.color = 'var(--emerald-accent)';
            showToast(`✓ Key verification PASSED (${elapsed}ms)`, 'success');
        } else {
            playUiSound('error');
            statusPill.textContent = `STATUS 200 • VERIFICATION DENIED`;
            statusPill.style.color = 'var(--rose-accent)';
            showToast(`✗ Verification Denied: ${data.message}`, 'error');
        }

        outputJson.textContent = JSON.stringify(data, null, 2);
        loadDashboard(); // Refresh telemetry to show this simulated check in the logs!
    } catch (error) {
        playUiSound('error');
        responseArea.style.display = 'block';
        statusPill.textContent = `STATUS 500 ERROR`;
        statusPill.style.color = 'var(--rose-accent)';
        outputJson.textContent = JSON.stringify({ error: error.message }, null, 2);
        showToast(`⚠ Verification request error: ${error.message}`, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg> <span>Simulate Verification</span>`;
    }
}

// Revoke License (Kill-Switch)
async function revokeLicense(id) {
    playUiSound('click');
    if (!confirm('⚠️ Are you sure you want to TRIGGER KILL-SWITCH for this license?\n\nThe client kiosk workstation will be locked out immediately on next heartbeat.')) return;

    try {
        const res = await adminFetch(`${API_BASE}/licenses/${id}/revoke`, {
            method: 'PUT',
            body: JSON.stringify({ reason: 'Manual Admin Console Revocation' })
        });
        const data = await res.json();
        if (data.success) {
            playUiSound('error');
            showToast('🚫 Kill-Switch triggered: License revoked', 'success');
            loadDashboard();
        }
    } catch (e) {
        showToast(`⚠ Failed to revoke: ${e.message}`, 'error');
    }
}

// Extend License
async function extendLicense(id) {
    playUiSound('click');
    const days = prompt('Enter additional validity days (e.g. 30, 90, 365):', '30');
    if (!days || isNaN(days)) return;

    try {
        const res = await adminFetch(`${API_BASE}/licenses/${id}/extend`, {
            method: 'PUT',
            body: JSON.stringify({ additional_days: parseInt(days, 10) })
        });
        const data = await res.json();
        if (data.success) {
            playUiSound('success');
            showToast(`✓ License extended by +${days} days!`, 'success');
            loadDashboard();
        }
    } catch (e) {
        showToast(`⚠ Failed to extend: ${e.message}`, 'error');
    }
}

// Delete License
async function deleteLicense(id) {
    playUiSound('click');
    if (!confirm('⚠️ Permanently delete this license record from the database?')) return;

    try {
        const res = await adminFetch(`${API_BASE}/licenses/${id}`, {
            method: 'DELETE'
        });
        const data = await res.json();
        if (data.success) {
            playUiSound('success');
            showToast('🗑 License record deleted', 'success');
            loadDashboard();
        }
    } catch (e) {
        showToast(`⚠ Failed to delete: ${e.message}`, 'error');
    }
}

// Export Licenses to CSV
function exportLicensesCSV() {
    playUiSound('click');
    if (!allLicenses || allLicenses.length === 0) {
        showToast('No license records to export', 'info');
        return;
    }

    const headers = ['ID', 'License Key', 'Customer Name', 'Email', 'Tier', 'Max Devices', 'Current Devices', 'Bound Device Names', 'Status', 'Expires At', 'Created At'];
    const rows = allLicenses.map(l => {
        const devNames = Array.isArray(l.device_names) ? l.device_names.join('; ') : (l.device_names || '');
        return [
            l.id,
            `"${l.license_key}"`,
            `"${(l.customer_name || '').replace(/"/g, '""')}"`,
            `"${(l.customer_email || '').replace(/"/g, '""')}"`,
            `"${l.tier}"`,
            l.max_activations,
            l.current_activations,
            `"${devNames.replace(/"/g, '""')}"`,
            l.status,
            `"${l.expires_at}"`,
            `"${l.created_at}"`
        ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `CBN_TECH_License_Registry_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('📊 Exported license registry to CSV', 'success');
}

// Export Licenses to JSON
function exportLicensesJSON() {
    playUiSound('click');
    if (!allLicenses || allLicenses.length === 0) {
        showToast('No license records to export', 'info');
        return;
    }

    const jsonString = JSON.stringify(allLicenses, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CBN_TECH_License_Ledger_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('💾 Exported license ledger to JSON', 'success');
}

// Toast Notifications
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    let iconSvg = '';
    if (type === 'success') {
        iconSvg = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>';
    } else if (type === 'error') {
        iconSvg = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#F43F5E" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>';
    } else {
        iconSvg = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#00F0FF" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>';
    }

    toast.innerHTML = `${iconSvg} <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(20px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
