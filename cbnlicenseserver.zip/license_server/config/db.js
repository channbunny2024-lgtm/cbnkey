const mysql = require('mysql2/promise');
require('dotenv').config();

const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '3306', 10),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'dpms_licenses',
    waitForConnections: true,
    connectionLimit: parseInt(process.env.DB_CONNECTION_LIMIT || '10', 10),
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 0
};

let pool = null;
let isConnected = false;

/**
 * Initializes the MySQL database, ensures the database schema exists, and creates tables.
 */
async function initDatabase() {
    try {
        // Step 1: Connect to MySQL server without database selected to ensure DB exists
        const rootConnection = await mysql.createConnection({
            host: dbConfig.host,
            port: dbConfig.port,
            user: dbConfig.user,
            password: dbConfig.password
        });

        await rootConnection.query(`CREATE DATABASE IF NOT EXISTS \`${dbConfig.database}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`);
        await rootConnection.end();

        // Step 2: Create Connection Pool for the database
        pool = mysql.createPool(dbConfig);

        // Test connection
        const conn = await pool.getConnection();
        conn.release();
        isConnected = true;
        console.log(`[Database] ✓ Connected to MySQL database '${dbConfig.database}' on ${dbConfig.host}:${dbConfig.port}`);

        // Step 3: Run Auto-Migrations / Table Creation
        await createTables();

        return pool;
    } catch (error) {
        console.error(`[Database] ⚠ MySQL Connection Failed (${error.message}).`);
        console.warn(`[Database] ℹ Please ensure MySQL server is running on ${dbConfig.host}:${dbConfig.port}.`);
        isConnected = false;
        return null;
    }
}

/**
 * Creates database tables and indexes if they do not already exist.
 */
async function createTables() {
    if (!pool) return;

    // 1. Licenses Table
    const createLicensesTable = `
        CREATE TABLE IF NOT EXISTS \`licenses\` (
            \`id\` INT AUTO_INCREMENT PRIMARY KEY,
            \`license_key\` VARCHAR(128) NOT NULL UNIQUE,
            \`key_hash\` VARCHAR(64) NOT NULL,
            \`encrypted_payload\` TEXT NOT NULL,
            \`customer_name\` VARCHAR(255) NOT NULL DEFAULT 'Valued Customer',
            \`customer_email\` VARCHAR(255) NULL,
            \`tier\` VARCHAR(50) NOT NULL DEFAULT 'Enterprise',
            \`max_activations\` INT NOT NULL DEFAULT 1,
            \`current_activations\` INT NOT NULL DEFAULT 0,
            \`status\` ENUM('active', 'expired', 'revoked', 'suspended') NOT NULL DEFAULT 'active',
            \`expires_at\` DATETIME NOT NULL,
            \`created_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            \`updated_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            \`notes\` TEXT NULL,
            INDEX \`idx_key_hash\` (\`key_hash\`),
            INDEX \`idx_status\` (\`status\`),
            INDEX \`idx_expires_at\` (\`expires_at\`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;

    // 2. License Activations Table (Machine bindings)
    const createActivationsTable = `
        CREATE TABLE IF NOT EXISTS \`license_activations\` (
            \`id\` INT AUTO_INCREMENT PRIMARY KEY,
            \`license_id\` INT NOT NULL,
            \`machine_name\` VARCHAR(255) NOT NULL,
            \`client_version\` VARCHAR(50) NOT NULL DEFAULT '1.0',
            \`ip_address\` VARCHAR(45) NULL,
            \`first_activated_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            \`last_heartbeat\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY \`uniq_license_machine\` (\`license_id\`, \`machine_name\`),
            CONSTRAINT \`fk_activation_license\` FOREIGN KEY (\`license_id\`) REFERENCES \`licenses\` (\`id\`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;

    // 3. Verification Logs Table (Telemetry & Audit)
    const createLogsTable = `
        CREATE TABLE IF NOT EXISTS \`verification_logs\` (
            \`id\` INT AUTO_INCREMENT PRIMARY KEY,
            \`license_key\` VARCHAR(128) NULL,
            \`is_valid\` BOOLEAN NOT NULL DEFAULT 0,
            \`status_code\` VARCHAR(50) NOT NULL,
            \`machine_name\` VARCHAR(255) NULL,
            \`ip_address\` VARCHAR(45) NULL,
            \`client_version\` VARCHAR(50) NULL,
            \`message\` TEXT NULL,
            \`timestamp\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX \`idx_log_timestamp\` (\`timestamp\`),
            INDEX \`idx_log_is_valid\` (\`is_valid\`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;

    await pool.query(createLicensesTable);
    await pool.query(createActivationsTable);
    await pool.query(createLogsTable);
    console.log('[Database] ✓ Schema tables (licenses, license_activations, verification_logs) verified.');
}

/**
 * Returns active database pool or throws if not connected.
 */
function getPool() {
    return pool;
}

function getIsConnected() {
    return isConnected;
}

module.exports = {
    initDatabase,
    getPool,
    getIsConnected,
    dbConfig
};
